#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define STR_SIZE 25
#define PLACE_NBR_SIZE 15
#define PLACE_PRIX_SIZE 25
#define BUFF_SIZE 1000


/* ******************************** */
/* -- D�claration des structures -- */
/* ******************************** */


typedef struct Date {
    int d;
    int m;
    int y;
} Date;

typedef struct event {
    char eventNum[STR_SIZE];
    char eventName[STR_SIZE];
    char lieu[STR_SIZE];
    char placenbr1[PLACE_NBR_SIZE];
    char placenbr2[PLACE_NBR_SIZE];
    char placeprix1[PLACE_PRIX_SIZE];
    char placeprix2[PLACE_PRIX_SIZE];
    Date eventdate;
} event;

typedef struct eventlist {
    event *e;
    int nbrevent;
    int allEventsLoaded;
} eventlist;


/* ********************************* */
/*        -- Initialisation --       */
/* ********************************* */


void initeventlist(eventlist *eL){
    eL->e = NULL;
    eL->nbrevent = 0;
    eL->allEventsLoaded = 0;
    printf("Initialisation OK!\n");
}


/* ********************************* */
/*  -- D�claration des fonctions --  */
/* ********************************* */


event geteventInfo();
void getString(char *str,int strSize,FILE *f);
void addevent(eventlist *el,event temp);
void menu (eventlist *eL, int selection);
int performMenu();
void printevent(eventlist el);
void loadEvents(eventlist *el);
void saveEvents(eventlist el);


/* ********************************* */
/*     -- Corps du programme --      */
/* ********************************* */


int main()
{
    eventlist eL;
    int selection;

    initeventlist(&eL);
    while(1){
        selection = performMenu();

        if(selection == 5){
                printf("A bientot! ;-)\n");
            break;
        }

        menu(&eL,selection);
    }return 0;
}


/* ********************************* */
/*  --  D�finition des fonctions --  */
/* ********************************* */


// Fonction d'affichage du menu
int performMenu(){
    int s;

    do{
        printf("\n");
        printf("------------------------- MENU -------------------------\n");
        printf("1 - Ajouter un evenement\n");
        printf("2 - Charger la liste des evenements enregistres\n");
        printf("3 - Afficher le(s) evenement(s)\n");
        printf("4 - Enregistrer les evenements dans un fichier.txt\n");
        printf("5 - Quitter\n");
        printf("--------------------------------------------------------\n");
        printf("=> Selection : ");
        scanf("%d",&s);
        printf("\n");
        while(getchar()!='\n');
    } while(s < 1 || s > 5);

    return s;
}


// Fonction qui appelle les diff�rentes fonctions suivant le choix du gestionnaire
void menu (eventlist *eL, int selection){
    event temp;

    switch(selection){
    case 1:
        if(eL->allEventsLoaded == 1){
            temp = geteventInfo();
            addevent(eL,temp);
        }
        else{
            printf("Veuillez charger les evenements enregistres\n\n");
        }
        break;

    case 2:
        loadEvents(eL);
        break;

    case 3:
        printevent(*eL);
        break;

    case 4:
        saveEvents(*eL);
        break;

     default :
         printf("Faites un autre choix svp 1--> 5 ! \n");
         break;
    }
}


// Fonction faisant l'acquisition d'une chaine de caract�res sans les retours chariot
void getString(char *str,int strSize,FILE *f)
{
    fgets(str,strSize,f);
    if(str[strlen(str)-1] == '\n'){
        str[strlen(str)-1] = '\0';
    }
	else{
        while(getc(f)!='\n');
	}
}


// Fonction qui fait l'acquisition des donn�es d'un �v�nement
event geteventInfo(){
    event e;
    printf("------ VEUILLEZ ENTRER LES DONNEES DE L'EVENEMENT ------\n\n");
    printf("1.Nom de l'evenement : " );
    getString(e.eventName,STR_SIZE,stdin);
    printf("2.Lieu de l'evenement : " );
    getString(e.lieu,STR_SIZE,stdin);
    printf("3.Nombre de places disponibles de la categorie 1: ");
    getString(e.placenbr1,PLACE_NBR_SIZE,stdin);
    printf("4.Prix des places disponibles pour la categorie 1 : ");
    getString(e.placeprix1,PLACE_PRIX_SIZE,stdin);
    printf("5.Nombre de places disponibles de la categorie 2: ");
    getString(e.placenbr2,PLACE_NBR_SIZE,stdin);
    printf("6.Prix des places disponibles pour la categorie 2 : ");
    getString(e.placeprix2,PLACE_PRIX_SIZE,stdin);
    printf("7.Date de l'evenement (jj/mm/aaaa): ");
    scanf("%d/%d/%d",&e.eventdate.d,&e.eventdate.m,&e.eventdate.y);
    while(getchar()!='\n');
    return e;
}


// Fonction qui ajoute les �v�nements � la liste
void addevent(eventlist *el,event temp){
    event *newElem;
    int i;

    if(el->nbrevent == 0){
        el->e = (event*) malloc(sizeof(event));
        el->e[0] = temp;
        el->nbrevent = 1;
    }
    else{
        newElem = (event*) malloc(sizeof(event)*(el->nbrevent+1));
        for(i = 0; i < el->nbrevent; i++){
            newElem[i] = el->e[i];
        }
        newElem[el->nbrevent] = temp;
        free(el->e);
        el->e = newElem;
        el->nbrevent++;
    }
    printf("\nAjout de l'evenement confirme !\n\n\n");
}


// Fonction qui affiche les �v�nements
void printevent(eventlist el){

    int i;
    printf("----------------- LISTE DES EVENEMENTS -----------------\n\n");

    if (el.nbrevent == 0){
        printf("Aucun evenement n'a ete cree recemment\n\n");
    }
    else {
        for(i = 0; i < el.nbrevent; i++){
            printf("Evenement : %d \n",i+1);
            printf("1.Nom de l'evenement: %s \n",el.e[i].eventName);
            printf("2.Lieu de l'evenement: %s \n",el.e[i].lieu);
            printf("3.Places disponibles de la categorie 1: %s\n",el.e[i].placenbr1);
            printf("4.Prix des places  pour la categorie 1 : %s\n",el.e[i].placeprix1);
            printf("5.Places disponibles de la categorie 2: %s\n",el.e[i].placenbr2);
            printf("6.Prix des places pour la categorie 2 : %s\n",el.e[i].placeprix2);
            printf("7.Date de l'evenement: %d/%d/%d\n\n",el.e[i].eventdate.d,el.e[i].eventdate.m,el.e[i].eventdate.y);
        }
    }
}


// Fonction qui charge les �v�nements
void loadEvents(eventlist *el){
    FILE *f;
    char Buffer[BUFF_SIZE];
    int i, j;
    event temp;

    if (el->allEventsLoaded == 1){
        printf("Vous avez deja charge les evenements enregistres\n\n");
    }
    else {
        f = fopen("Liste.txt","r");
        if (f != NULL){

            fgets(Buffer, BUFF_SIZE, f);
            fscanf(f, "%d", &j);
            printf("Nombre d'evenement(s) encode(s) : %d\n\n", j);

            for (i = 0; i < j; i++){

                fgets(Buffer, BUFF_SIZE, f);
                fgets(Buffer, BUFF_SIZE, f);
                fscanf(f, "%s", &*temp.eventNum);
                fgets(Buffer, BUFF_SIZE, f);
                fscanf(f, "%[^\n]", &*temp.eventName);
                fgets(Buffer, BUFF_SIZE, f);
                fscanf(f, "%[^\n]", &*temp.lieu);
                fgets(Buffer, BUFF_SIZE, f);
                fscanf(f, "%s", &*temp.placenbr1);
                fgets(Buffer, BUFF_SIZE, f);
                fscanf(f, "%s", &*temp.placeprix1);
                fgets(Buffer, BUFF_SIZE, f);
                fscanf(f, "%s", &*temp.placenbr2);
                fgets(Buffer, BUFF_SIZE, f);
                fscanf(f, "%s", &*temp.placeprix2);
                fgets(Buffer, BUFF_SIZE, f);
                fscanf(f, "%d/%d/%d", &temp.eventdate.d, &temp.eventdate.m, &temp.eventdate.y);

                printf("Numero de l'evenement : %s\n", temp.eventNum);
                printf("Nom de l'evenement : %s\n", temp.eventName);
                printf("Lieu de l'evenement : %s\n", temp.lieu);
                printf("Places disponibles de la categorie 1 : %s\n", temp.placenbr1);
                printf("Prix des places disponibles pour la categorie 1 : %s\n", temp.placeprix1);
                printf("Places disponibles de la categorie 2 : %s\n", temp.placenbr2);
                printf("Prix des places disponibles pour la categorie 2 : %s\n", temp.placeprix2);
                printf("Date de l'evenement : %d/%d/%d\n", temp.eventdate.d, temp.eventdate.m, temp.eventdate.y);

                addevent(el,temp);
            }
            el->allEventsLoaded = 1;
            fclose(f);
        }
        else{
            printf("File Error!\n");
        }
    }
}


// Fonction qui enregistre les �v�nements
void saveEvents(eventlist el){
    FILE *f;
    int i;
    if(el.allEventsLoaded == 0){
        loadEvents(&el);
    }

    f = fopen("Liste.txt","w+");

    if(f != NULL){

        fprintf(f,"-- Event List --\n");
        fprintf(f,"%d\n\n",el.nbrevent); // Nombre d'�v�nements encod�s

        for(i = 0; i < el.nbrevent; i++){

            fprintf(f,"%d\n",i+1); // Num�ro de l'�v�nement
            fprintf(f,"%s\n",el.e[i].eventName); // Nom de l'�v�nement
            fprintf(f,"%s\n",el.e[i].lieu); // Lieu de l'�v�nement
            fprintf(f,"%s\n",el.e[i].placenbr1); // Places disponibles de la cat�gorie 1
            fprintf(f,"%s\n",el.e[i].placeprix1); //Prix des places disponibles pour la cat�gorie 1
            fprintf(f,"%s\n",el.e[i].placenbr2); // Places disponibles de la cat�gorie 2
            fprintf(f,"%s\n",el.e[i].placeprix2); // Prix des places disponibles pour la cat�gorie 2
            fprintf(f,"%d/%d/%d\n\n",el.e[i].eventdate.d,el.e[i].eventdate.m,el.e[i].eventdate.y); // Date de l'�v�nement
        }
        fclose(f);
        printf("Ecriture du fichier reussie!\n");
    }

    else{
        printf("File Error!\n");
    }
}
