#ifndef STRUCTURES_H_INCLUDED
#define STRUCTURES_H_INCLUDED

#include <stdio.h>

#include <stdlib.h>



#define STR_SIZE 25

#define PLACE_NBR_SIZE 15

#define PLACE_PRIX_SIZE 25

#define NBR_MAX_CAT 10



typedef struct Date Date;

typedef struct event event;

typedef struct eventlist eventlist;

typedef struct Categorie Categorie;





struct Date

{

    int d;

    int m;

    int y;

};



struct Categorie  // nouvelle structure

{



    char nameCat[STR_SIZE];

    int placenbr;

    double placeprix;





};




struct event

{
    char eventName[STR_SIZE];
    char typevent[STR_SIZE]; // New
    char lieu[STR_SIZE];
    int catnbr;           // New
    Categorie eventCat[NBR_MAX_CAT] ; // New : tableau de structure de type Categorie
    Date eventdate;
    char inutile[STR_SIZE];
    event *prev;   // New
    event *next;   // New
};



struct eventlist

{
    event *first; // New
    event *last;  // New
    int nbrevent;

};



void printtype(eventlist el);

void initeventlist(eventlist *eL);

void addevent(eventlist *eL,event temp);

void printevent(eventlist el);

void saveEvents(eventlist el);

void removeeventlist(eventlist *el);

event geteventInfo();

void getString(char *str,int strSize,FILE *f);

void loadeventlist(eventlist *eL);








#endif // STRUCTURES_H_INCLUDED
