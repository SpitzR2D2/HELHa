#include "Structures.h"

#include <stdio.h>

#include <stdlib.h>

#include <string.h>



int performMenu();

void menu(eventlist *eL, int selection);

int main()

{

    eventlist eL;

    int selection;



    initeventlist(&eL);

    while(1){

        selection = performMenu();



        if(selection == 6){

            printf("A bientot !!\n");

            break;

        }



        menu(&eL,selection);

    }

    removeeventlist(&eL);

    return 0;

}



int performMenu(){

    int s;



    do{

        printf("\n");

        printf("--------------- MENU ---------------\n");

        printf("1 - Ajouter un evenement\n");

        printf("2 - Afficher la liste des evenements\n");

        printf("3 - Enregistrer la liste dans un fichier .txt\n");

        printf("4 - Afficher les evenements d'un type\n");

        printf("5 - Charger les evenements a partir d'un fichier .txt\n");

        printf("6 - Quitter\n");

        printf("------------------------------------\n");

        printf("Selection: ");

        scanf("%d",&s);

        printf("\n");

        while(getchar()!='\n');

    }while(s < 1 || s > 6);



    return s;

}



void menu (eventlist *eL, int selection){

    event temp;


    switch(selection){

        case 1:

            temp = geteventInfo();

            addevent(eL,temp);

            break;



        case 2:

            printevent(*eL);

            break;



        case 3:

            saveEvents(*eL);

            break;



        case 4:
            printtype (*eL);

            break;

        case 5:
            removeeventlist(eL);
            initeventlist(eL);
            loadeventlist(eL);
            break;

        default :

            printf("Faites un autre choix svp 1--> 5 ! \n");

            break;

    }

}

