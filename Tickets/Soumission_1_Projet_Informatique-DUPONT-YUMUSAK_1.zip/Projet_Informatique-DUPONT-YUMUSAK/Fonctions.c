#include "Structures.h"

#include <stdio.h>

#include <stdlib.h>

#include <string.h>





void initeventlist(eventlist *eL)



{

    eL->first = NULL;
    eL->last = NULL;
    eL->nbrevent = 0;
    printf("Init OK!\n");

}





void addevent(eventlist *el,event temp)

{

    event *newElem;

    newElem = (event*) malloc(sizeof(event)); //Alouer de la memoire



    *newElem = temp;

    newElem->next = NULL;

    newElem->prev = el->last;



    if(el-> last == NULL)

    {

        el->first = newElem;



    }

    else

    {

        el->last->next = newElem;

    }



    el->last = newElem;

    el->nbrevent++;



    printf("Ajout confirme !\n");

}






void printevent(eventlist el){



    event *p;

    p = el.first;

    int i=0;

    int j=1;

    printf("---- Liste des evenements ----\n\n");



    while(p != NULL)

    {



        printf("Evenement : %d \n",i+1);

        printf("1.Type de l'evenement (sportif/culturel): %s \n",p->typevent);

        printf("2.Nom de l'evenement: %s \n",p->eventName);

        printf("3.Lieu de l'evenement: %s \n",p->lieu);

        printf("5.Date de l'evenement: %d/%d/%d\n\n",p->eventdate.d,p->eventdate.m,p->eventdate.y);

        printf("4.Nombre de categories de tickets : %d",p->catnbr);

        for(j = 0 ; j< (p->catnbr) ;j++ )

        {

            printf("\n--------- Informations de la categorie de tickets n｡[%d]----------\n\n",j+1);

            printf("Nom de la categorie de tickets n｡[%d] : %s \n",j+1,(p->eventCat[j].nameCat));

            printf("Nombre de places de la categorie de tickets n｡[%d]: %d \n",j+1,p->eventCat[j].placenbr);

            printf("Prix de la categorie de tickets n｡[%d] : %2.lf \n",j,p->eventCat[j].placeprix);



        }




        printf ("\n\n");

        p = p->next;

        i++;

        }

}





event geteventInfo(){

    event e;

    int i=0;

    printf("----- Veuillez entrer les donnees de l'evenement -----\n\n");

    printf("1.Type de l'evenement (sportif/culturel) : " );

    getString(e.typevent,STR_SIZE,stdin);

    printf("2.Nom de l'evenement : " );

    getString(e.eventName,STR_SIZE,stdin);

    printf("3.Lieu de l'evenement : " );

    getString(e.lieu,STR_SIZE,stdin);

    printf("4.Entrez le nombre de categories de tickets : ");

    scanf("%d",&e.catnbr);

    while(getchar()!='\n');

    printf("\n");



    do

    {

        printf("\n--------- Encodage des informations de la categorie de tickets n｡[%d]----------\n\n",i+1);

        printf("4.1.Nom de la categorie de tickets n｡[%d] : ",i+1);

        getString(e.eventCat[i].nameCat,STR_SIZE,stdin);

        printf("4.2.Nombre de places de la categorie de tickets n｡[%d]: ",i+1);

        scanf("%d",&e.eventCat[i].placenbr);

        while(getchar()!='\n');

        printf("4.3.Prix de la categorie de tickets n｡[%d] : ",i+1);

        scanf("%lf",&e.eventCat[i].placeprix);

        while(getchar()!='\n');

        i++;

    }while(i<e.catnbr);



    printf("5.Date de l'evenement (jj/mm/aaaa): ");

    scanf("%d/%d/%d",&e.eventdate.d,&e.eventdate.m,&e.eventdate.y);

    while(getchar()!='\n');

    return e;

}



void getString(char *str,int strSize,FILE *f)

{

    fgets(str,strSize,f);

    if(str[strlen(str)-1] == '\n'){

        str[strlen(str)-1] = '\0';

    }

	else{

        while(getc(f)!='\n');

	}

}



void saveEvents(eventlist el){          //enregistrer dans un fichier texte

    FILE *f;

    event *p;

    p = el.first;

    int i=0;

    int j=0;



    f = fopen("Liste.txt","w");   // si je met a il met tout à la suite de l'autre donc il enregistre toutes les fonctions crees

    if(f != NULL){



        fprintf(f,"-- Event List --\n");

        fprintf(f,"Nombre d'event encode(s): \n%d\n\n",el.nbrevent);



    while(p != NULL)

        {

        fprintf(f,"Evenement : %d \n\n",i+1);

        fprintf(f,"\n%s \n",p->typevent);

        fprintf(f,"\n%s \n",p->eventName);

        fprintf(f,"\n%s \n",p->lieu);

        fprintf(f,"\n%d \n%d \n%d \n",p->eventdate.d,p->eventdate.m,p->eventdate.y);

        fprintf(f,"\nNombre de categorie :\n%d\n",p->catnbr);

        for(j = 0 ; j< (p->catnbr) ;j++ )

        {

            fprintf(f,"\n%s \n",(p->eventCat[j].nameCat));

            fprintf(f,"%d \n",p->eventCat[j].placenbr);

            fprintf(f,"%2.lf \n",p->eventCat[j].placeprix);



        }
        fprintf(f,"\n");

        p = p->next;

        i++;

        }

        fclose(f);

        printf("Writting File OK!\n");

    }

    else{

        printf("File Error!\n");

    }

}

void removeeventlist(eventlist *el)

{

    event *p,*temp;

    p = el->first;



    while(p != NULL)

    {

        temp = p;

        p = p->next;

        free(temp);

    }

    printf("Remove OK!\n");

}







//A test






//test pour afficher en fonction du type d'event



void printtype(eventlist el){



    event *p;

    p = el.first;

    int i=0;

    int j;

    int k;

    char choix [STR_SIZE];

    printf("\nEvenement souhaite (sportif/culturel): ");

    getString(choix,STR_SIZE,stdin);

    //while(getchar()!='\n');

    printf("\n---- Liste des evenements de type %s ----\n\n",choix);


    while(p != NULL)

    {

            if(strlen(choix)==strlen(p->typevent))

            {

                printf("Evenement : %d \n",i+1);

                printf("1.Nom de l'evenement: %s \n",p->eventName);

                printf("2.Lieu de l'evenement: %s \n",p->lieu);

                printf("3.Nombre de categories de tickets : %d",p->catnbr);

                for(j = 0 ; j< (p->catnbr) ;j++ )

                {

                    printf("\n--------- Informations de la categorie de tickets n｡[%d]----------\n\n",j+1);

                    printf("3.1.Nom de la categorie de tickets n｡[%d] : %s \n",j+1,(p->eventCat[j].nameCat));

                    printf("3.2.Nombre de places de la categorie de tickets n｡[%d]: %d \n",j+1,p->eventCat[j].placenbr);

                    printf("3.3.Prix de la categorie de tickets n｡[%d] : %2.lf \n",j,p->eventCat[j].placeprix);



                }

                printf("4.Date de l'evenement: %d/%d/%d\n\n",p->eventdate.d,p->eventdate.m,p->eventdate.y);

                printf ("-------------------------------------------------\n\n");
                i++;


            }
            else if (strlen(choix)!=strlen(p->typevent))
            {

                    printf("\nIl n'y a pas d'evenements de type %s \n",choix);
                    break;
            }


            p = p->next;

    }

}
void loadeventlist(eventlist *eL)
{
    FILE *f;
    event c;
    int i=0,j,x=0;
    f = fopen("Liste.txt","r");
    if(f != NULL)
    {
        getString(c.inutile,STR_SIZE,f);
        getString(c.inutile,STR_SIZE,f);
        fscanf(f,"%d",&i);
        getString(c.inutile,STR_SIZE,f);
        for(j = 0; j < i; j++)
        {
            while(getc(f)!='\n');
            getString(c.inutile,STR_SIZE,f);
            getString(c.inutile,STR_SIZE,f);
            getString(c.inutile,STR_SIZE,f);
            getString(c.typevent,STR_SIZE,f);
            getString(c.inutile,STR_SIZE,f);
            getString(c.eventName,STR_SIZE,f);
            getString(c.inutile,STR_SIZE,f);
            getString(c.lieu,STR_SIZE,f);
            getString(c.inutile,STR_SIZE,f);
            fscanf(f,"%d",&c.eventdate.d);
            fscanf(f,"%d",&c.eventdate.m);
            fscanf(f,"%d",&c.eventdate.y);
            getString(c.inutile,STR_SIZE,f);
            getString(c.inutile,STR_SIZE,f);
            while(getc(f)!='\n');
            fscanf(f,"%d",&c.catnbr);
            getString(c.inutile,STR_SIZE,f);
            for (x=0;x<c.catnbr;x++)
            {

                while(getc(f)!='\n');
                getString(c.eventCat[x].nameCat,STR_SIZE,f);

                fscanf(f,"%d",&c.eventCat[x].placenbr);

                fscanf(f,"%lf",&c.eventCat[x].placeprix);
                getString(c.inutile,STR_SIZE,f);

            }


            addevent(eL,c);
        }
        fclose(f);
        printf("Loading File OK!\n");
    }

    else
    {
        printf("File Error!\n");
    }
}

