#ifndef INTERFACE_H_INCLUDED
#define INTERFACE_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CLEARSCREEN system("cls")

int choixMenu(Matche * premierMatch);
int AfficheMatch(Matche * matchSelectionne);
int AfficheParisSomme(Matche * matchSelectionne,int numerojoueur);
int AfficheParisJoueurs(Matche * matchSelectionne);
int AfficheParisConfirmation(Matche * matchSelectionne,int numerojoueur,int somme,char * prenom);
char*AfficheParisPrenom(Matche * matchSelectionne,int numerojoueur,int somme);
void AfficheListParis(Paris * premierParis);

#endif // INTERFACE_H_INCLUDED
