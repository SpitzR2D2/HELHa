#include "Header.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int choixMenu(Matche * premierMatch){
	CLEARSCREEN;
	int choix;
	char * choixStr = (char*)malloc(4*sizeof(char));
	int i = 0;

	Matche * matchActuel = premierMatch;
	printf("------------ Affiche des matches ------------\n");
	while(i < 7){
        printf("%d) D : %s \n", matchActuel->numero,matchActuel->dates);
        printf("    %s VS %s \n", matchActuel->joueur1->nom,matchActuel->joueur2->nom);
        printf("---------------------------------------------\n");
        matchActuel = matchActuel->matchesvt;
        i++;
	}
	printf("Selection : ");
	scanf("%s", choixStr);
	choix = atoi(choixStr);
	printf("%d \n",choix);

	if (choix == 0 || choix > 7){
        printf("---------------------------------------------\n");
        printf(" Option invalide: appuyer sur ENTER          \n");
        printf("---------------------------------------------\n");
        choix = -1;
	}
	free(choixStr);
	return choix;
}

int AfficheMatch(Matche * matchSelectionne){
	CLEARSCREEN;
	char choix;

	printf("------------ Affiche du matche ------------\n");
	printf(" Boxeur N1 : %s\n",matchSelectionne->joueur1->nom);
	printf("Victoires : %d Defaites: %d Nulls :%d\n",matchSelectionne->joueur1->victoires,matchSelectionne->joueur1->defaites,matchSelectionne->joueur1->nulls);
	printf("---------------------------------------------\n");
	printf(" Boxeur N2 : %s\n",matchSelectionne->joueur2->nom);
	printf("Victoires : %d Defaites: %d Nulls :%d\n",matchSelectionne->joueur2->victoires,matchSelectionne->joueur2->defaites,matchSelectionne->joueur2->nulls);
	printf("---------------------------------------------\n");
	printf("Voulez-vous faire un nouveau paris (o/n)? \n");
	printf("---------------------------------------------\n");
	printf("Selection : ");
	scanf("%c",&choix);
	if (choix == 'o'){
        return 1;
	}
	else if (choix == 'n'){
        return 0;
	}
	else{
        return AfficheMatch(matchSelectionne);
	}
}
int AfficheParisJoueurs(Matche * matchSelectionne){
	CLEARSCREEN;
	char choix;

	printf("------------ Affiche du paris ------------\n");
	printf("%d) D : %s \n", matchSelectionne->numero,matchSelectionne->dates);
    printf("    %s VS %s \n", matchSelectionne->joueur1->nom,matchSelectionne->joueur2->nom);
    printf("---------------------------------------------\n");
    printf(" NOM : \n");
    printf(" SOMME : \n");
    printf(" PARIEUR : \n");
    printf("---------------------------------------------\n");
    printf(" Sur quel boxeur voulez-vous parier ? \n");
    printf("Pour %s tapez 1 et pour %s tapez 2 \n",matchSelectionne->joueur1->nom,matchSelectionne->joueur2->nom);
    printf("---------------------------------------------\n");
    scanf("%c",&choix);

    if (choix == '1'){
        return 1;
	}
	else if (choix == '2'){
        return 0;
	}
	else{
        return AfficheParisJoueurs(matchSelectionne);
	}
}

int AfficheParisSomme(Matche * matchSelectionne,int numerojoueur){
	CLEARSCREEN;
	char * choixStr = (char*)malloc(10*sizeof(char));
	int choix;

	printf("------------ Affiche du paris ------------\n");
	printf("%d) D : %s \n", matchSelectionne->numero,matchSelectionne->dates);
    printf("    %s VS %s \n", matchSelectionne->joueur1->nom,matchSelectionne->joueur2->nom);
    printf("---------------------------------------------\n");
    if (numerojoueur == 1){
        printf(" NOM : %s \n",matchSelectionne->joueur1->nom);
    }
    else{
        printf(" NOM : %s \n",matchSelectionne->joueur2->nom);
    }
    printf(" SOMME : \n");
    printf(" PARIEUR : \n");
    printf("---------------------------------------------\n");
    printf(" Quelle somme voulez-vous miser? \n");
    printf("---------------------------------------------\n");

    scanf("%s", choixStr);
	choix = atoi(choixStr);

	free(choixStr);
    if (choix != 0){
        return choix;
	}
	else {
        return AfficheParisSomme(matchSelectionne,numerojoueur);
	}
}
char*AfficheParisPrenom(Matche * matchSelectionne,int numerojoueur,int somme){
	CLEARSCREEN;
	char * choixStr = (char*)malloc(20*sizeof(char));

	printf("------------ Affiche du paris ------------\n");
	printf("%d) D : %s \n", matchSelectionne->numero,matchSelectionne->dates);
    printf("    %s VS %s \n", matchSelectionne->joueur1->nom,matchSelectionne->joueur2->nom);
    printf("---------------------------------------------\n");
    if (numerojoueur == 1){
        printf(" NOM : %s \n",matchSelectionne->joueur1->nom);
    }
    else{
        printf(" NOM : %s \n",matchSelectionne->joueur2->nom);
    }
    printf(" SOMME : %d \n",somme);
    printf(" PARIEUR : \n");
    printf("---------------------------------------------\n");
    printf(" Quel est votre prenom ?\n");
    printf("---------------------------------------------\n");

    scanf("%s", choixStr);

	if(choixStr != "\n"){
        return choixStr;
	}
	else{
        return AfficheParisPrenom(matchSelectionne,numerojoueur,somme);
	}
}
int AfficheParisConfirmation(Matche * matchSelectionne,int numerojoueur,int somme, char*prenom){
	CLEARSCREEN;
	char choix;

	printf("------------ Affiche du paris ------------\n");
	printf("%d) D : %s \n", matchSelectionne->numero,matchSelectionne->dates);
    printf("    %s VS %s \n", matchSelectionne->joueur1->nom,matchSelectionne->joueur2->nom);
    printf("---------------------------------------------\n");
    if (numerojoueur == 1){
        printf(" NOM : %s \n",matchSelectionne->joueur1->nom);
    }
    else{
        printf(" NOM : %s \n",matchSelectionne->joueur2->nom);
    }
    printf(" SOMME : %d \n",somme);
    printf(" PARIEUR : %s \n",prenom);
    printf("---------------------------------------------\n");
    printf(" Voulez-vous confirmer votre paris  (o/n)? \n");
    printf("---------------------------------------------\n");

    scanf("%c",&choix);

    if (choix == 'o'){
        return 1;
	}
	else if (choix == 'n'){
        return 0;
	}
	else{
        return AfficheParisConfirmation(matchSelectionne,numerojoueur,somme,prenom);
	}
}

void AfficheListParis(Paris * premierParis){
	CLEARSCREEN;
	int count =1;
	Paris * parisActuel = premierParis;
	printf("------------ Affiche Liste des paris ------------\n");

	while(parisActuel != NULL){
        printf(" Prenom du parieur :  %s\n",parisActuel->prenom);
        printf("%d) Date : %s\n", count, parisActuel->matche->dates);
        printf("    %s VS %s \n", parisActuel->matche->joueur1->nom,parisActuel->matche->joueur2->nom);
        if(parisActuel->selection == 1)
        {
            printf("Vous avez parie %d sur %s \n",parisActuel->somme,parisActuel->matche->joueur1->nom);
        }
        else
        {
            printf("Vous avez parie %d sur %s \n",parisActuel->somme,parisActuel->matche->joueur2->nom);
        }
        printf("---------------------------------------------\n");
        parisActuel = parisActuel->parissvt;
        count ++;
	}
	printf(" Appuyez sur la touche 't' pour terminer . \n");
	while( getchar() != 't' );
}
