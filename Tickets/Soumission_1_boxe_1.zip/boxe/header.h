#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CLEARSCREEN system("cls")


typedef struct Boxeur Boxeur;
typedef struct Matche Matche;
typedef struct Paris Paris;

struct Boxeur{
	char nom[15];
	int victoires;
	int defaites;
	int nulls;
	Boxeur * boxeursvt;
};
struct Matche{
    int  numero;
	char dates[10];
	Boxeur * joueur1;
	Boxeur * joueur2;
	Matche * matchesvt;
};

struct Paris{
    int selection;
    Matche * matche;
    int somme;
    char prenom [20];
    Paris * parissvt;
};


Boxeur * chargerBoxeur (FILE * fichierBoxeur);
Matche * chargerMatche (FILE * fichierMatche,Boxeur * premierBoxeur);
Boxeur * TrouverBoxeur(char * nomBoxeur, Boxeur * premierboxeur);
Matche * TrouverMatche(int numero, Matche * premiermatche);
Paris * creerParis(Paris * premierParis,int numeroJ,int somme,char * prenom,Matche* matcheparis);
int choixMenu(Matche * premierMatch);
int AfficheMatch(Matche * matchSelectionne);
int AfficheParisSomme(Matche * matchSelectionne,int numerojoueur);
int AfficheParisJoueurs(Matche * matchSelectionne);
int AfficheParisConfirmation(Matche * matchSelectionne,int numerojoueur,int somme,char * prenom);
char*AfficheParisPrenom(Matche * matchSelectionne,int numerojoueur,int somme);
void AfficheListParis(Paris * premierParis);

#endif // HEADER_H_INCLUDED
