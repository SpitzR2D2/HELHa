#include <stdio.h>
#include <stdlib.h>
#include "Header.h"

int main()
{

    FILE *fichier = NULL;
    Boxeur *premierBoxeur = NULL;
    Paris *premierParis = NULL;
    Matche *premierMatche = NULL;

    fichier = fopen("Boxeurs.txt","r");
    if (fichier != NULL)
    {
            premierBoxeur = chargerBoxeur(fichier);
    }
    else{
        printf("FILE NOT FOUND");
        exit(-1);
    }
    // Boxeur *actBoxeur = premierBoxeur;
    fclose(fichier);

    fichier = fopen("match.txt","r");

    if (fichier != NULL)
    {
            premierMatche = chargerMatche(fichier,premierBoxeur);
    }
    else{
        printf("FILE NOT FOUND");
        exit(-1);
    }
    //Matche *actMatche = premierMatche;
    fclose(fichier);

    while (1){
        int choix = choixMenu(premierMatche);
        int numeroJ;
        int somme;
        char*prenom;
        int confirmation;

        if (choix == -1){
            continue;
        }
        Matche *matchSelectionne = TrouverMatche(choix, premierMatche);
        if(AfficheMatch(matchSelectionne) == 1)
        {
            numeroJ = AfficheParisJoueurs(matchSelectionne);
            somme = AfficheParisSomme(matchSelectionne,numeroJ);
            prenom = AfficheParisPrenom(matchSelectionne,numeroJ,somme);
            confirmation = AfficheParisConfirmation(matchSelectionne,numeroJ,somme,prenom);
            printf("vous avez choisi %d \n ",confirmation);
            if (confirmation == 1)
            {
                premierParis = creerParis(premierParis,numeroJ,somme,prenom,matchSelectionne);
            }
            if(premierParis == NULL)
            {
                CLEARSCREEN;
                printf("---------------------------------------------\n");
                printf(" Aucun paris n'a ete confime. \n");
                printf("---------------------------------------------\n");
                printf(" Appuyez sur la touche 't' pour terminer . \n");
                while( getchar() != 't' );
            }
            else
            {
                AfficheListParis(premierParis);
            }
        }
    }

}
